// Fill out your copyright notice in the Description page of Project Settings.


#include "BTTask_RangedAttack.h"
#include "ABAIController.h"
#include "ABCharacter.h"

//#include "ChaseBallActor.h"
//#include "ChaseBallActor.generated.h"

#include "Engine/World.h"
#include "BehaviorTree/BlackboardComponent.h"
//class AChaseBallActor;

UBTTask_RangedAttack::UBTTask_RangedAttack() 
{
	bNotifyTick = true;
	IsAttacking = false;
}

EBTNodeResult::Type UBTTask_RangedAttack::ExecuteTask(UBehaviorTreeComponent & OwnerComp, uint8 * NodeMemory)
{
	EBTNodeResult::Type Result = Super::ExecuteTask(OwnerComp, NodeMemory);

	auto ABCharacter = Cast<AABCharacter>(OwnerComp.GetAIOwner()->GetPawn());
	if (nullptr == ABCharacter) {
		return EBTNodeResult::Failed;
	}
	ABCharacter->RangedAttack();
	IsAttacking = true;
	ABCharacter->OnAttackEnd.AddLambda([this]()->void {IsAttacking = false; });
	//���Ÿ� ���� ī��Ʈ
	OwnerComp.GetBlackboardComponent()->SetValueAsInt("RangedAttackCounts", OwnerComp.GetBlackboardComponent()->GetValueAsInt("RangedAttackCounts") + 1);

	UPROPERTY()
	UWorld* World = GetWorld();
	if (World == nullptr) {
		return EBTNodeResult::Failed;
	}
	FActorSpawnParameters sParams;
	sParams.Owner = ABCharacter;
	//AChaseBallActor* Projectile = World->SpawnActor<AChaseBallActor>();

	return EBTNodeResult::InProgress;
}

void UBTTask_RangedAttack::TickTask(UBehaviorTreeComponent & OwnerComp, uint8 * NodeMemory, float DeltaSeconds)
{
	Super::TickTask(OwnerComp, NodeMemory, DeltaSeconds);

	if (!IsAttacking) {
		FinishLatentTask(OwnerComp, EBTNodeResult::Succeeded);
	}
}
