// Fill out your copyright notice in the Description page of Project Settings.

#include "ArenaBattle.h"
#include "Modules/ModuleManager.h"


DEFINE_LOG_CATEGORY(ArenaBattle);
IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, ArenaBattle, "ArenaBattle" );
